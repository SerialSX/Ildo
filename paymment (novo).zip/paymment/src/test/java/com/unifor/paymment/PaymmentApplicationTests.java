package com.unifor.paymment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
