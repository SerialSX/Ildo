package com.unifor.paymment;

import com.unifor.paymment.context.PaymentContext;
import com.unifor.paymment.strategies.BoletoPayment;
import com.unifor.paymment.strategies.LogPaymentDecorator;
import com.unifor.paymment.strategies.NotificationPaymentDecorator;

public class PaymmentApplication {
	public static void main(String[] args) {
		PaymentContext context = PaymentContext.getInstance();

		// Criando pagamento com boleto + log + notificação
		context.setPaymentStrategy(
				new NotificationPaymentDecorator(
						new LogPaymentDecorator(
								new BoletoPayment()
						)
				)
		);

		context.processPayment(250.0);
	}
}
