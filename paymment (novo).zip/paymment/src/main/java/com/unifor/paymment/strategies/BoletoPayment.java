package com.unifor.paymment.strategies;

import com.unifor.paymment.interfaces.PaymentStrategy;

public class BoletoPayment implements PaymentStrategy {
    @Override
    public void pay(double amount) {
        System.out.println("Processando pagamento via Boleto no valor de R$ " + amount);
    }
}
