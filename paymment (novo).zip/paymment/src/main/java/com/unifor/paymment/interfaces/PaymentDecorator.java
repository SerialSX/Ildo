// Interface já existente
public interface PaymentStrategy {
    void pay(double amount);
}

// Classe abstrata (Decorator base)
public abstract class PaymentDecorator implements PaymentStrategy {
    protected PaymentStrategy decoratedPayment;

    public PaymentDecorator(PaymentStrategy decoratedPayment) {
        this.decoratedPayment = decoratedPayment;
    }

    @Override
    public void pay(double amount) {
        decoratedPayment.pay(amount); // delega para o "pagamento real"
    }
}
