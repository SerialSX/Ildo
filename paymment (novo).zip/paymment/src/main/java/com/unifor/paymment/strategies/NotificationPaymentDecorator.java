package com.unifor.paymment.strategies;

import com.unifor.paymment.interfaces.PaymentStrategy;
import com.unifor.paymment.interfaces.PaymentDecorator;

public class NotificationPaymentDecorator extends PaymentDecorator {

    public NotificationPaymentDecorator(PaymentStrategy decoratedPayment) {
        super(decoratedPayment);
    }

    @Override
    public void pay(double amount) {
        super.pay(amount);
        System.out.println("[NOTIFICAÇÃO] Enviando confirmação ao usuário.");
    }
}
