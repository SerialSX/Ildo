package com.unifor.paymment.strategies;

import com.unifor.paymment.interfaces.PaymentStrategy;
import com.unifor.paymment.interfaces.PaymentDecorator;

public class LogPaymentDecorator extends PaymentDecorator {

    public LogPaymentDecorator(PaymentStrategy decoratedPayment) {
        super(decoratedPayment);
    }

    @Override
    public void pay(double amount) {
        System.out.println("[LOG] Iniciando pagamento...");
        super.pay(amount);
        System.out.println("[LOG] Pagamento concluído!");
    }
}
