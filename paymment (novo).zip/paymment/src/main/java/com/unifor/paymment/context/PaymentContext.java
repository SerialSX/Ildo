package com.unifor.paymment.context;

import com.unifor.paymment.interfaces.PaymentStrategy;

public class PaymentContext {

    // 🔹 Singleton
    private static PaymentContext instance;

    private PaymentStrategy paymentStrategy;

    // Construtor privado
    private PaymentContext() {}

    // Retorna a instância única
    public static PaymentContext getInstance() {
        if (instance == null) {
            instance = new PaymentContext();
        }
        return instance;
    }

    // Métodos normais
    public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void processPayment(double amount) {
        if (paymentStrategy == null) {
            throw new IllegalStateException("Nenhuma estratégia de pagamento definida!");
        }
        paymentStrategy.pay(amount);
    }
}
