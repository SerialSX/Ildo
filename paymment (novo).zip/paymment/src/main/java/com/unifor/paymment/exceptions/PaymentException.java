package com.unifor.paymment.exceptions;

public class PaymentException extends Exception{
    public PaymentException(String message){
        super(message);
    }
}
